// Nodemon restart trigger v7
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');
const connectDB = require('./config/db');
const { initFCM } = require('./services/fcm');
const http = require('node:http');
require('./models/ImportHistory');
require('./models/Payment');
const { WebSocketServer } = require('ws');
const { handleCall } = require('./services/aiCaller/orchestrator'); // NEW: in-process AI call orchestrator
const { startSchedulePoller } = require('./services/workflowEngine');
const { startOverdueTaskChecker } = require('./services/taskOverdueChecker');
const campaignEngine = require('./services/aiCaller/campaignEngine');
const callbackEngine = require('./services/aiCaller/callbackEngine');
const { startSheetsAutoSyncPoller } = require('./services/sheetsAutoSync');
const dns = require('node:dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);

const app = express();
connectDB();

initFCM();

// ── Security ─────────────────────────────────────────────────────────────────
// A single exact-string origin match (the old approach) silently breaks CORS
// for every route if the configured FRONTEND_URL differs from the browser's
// origin by so much as a trailing slash or a missing "www." — with no error
// logged anywhere, since the request is still handled fine, just without the
// CORS header. This matcher normalizes both sides and accepts the www/non-www
// variant of whatever's configured, so that class of mismatch can't happen.
const configuredOrigin = (process.env.FRONTEND_URL || '').trim().replace(/\/+$/, '');

function normalizeOrigin(o) {
  return (o || '').trim().replace(/\/+$/, '');
}

function isAllowedOrigin(origin) {
  if (!configuredOrigin) return true; // no FRONTEND_URL set -> behave like the old '*' fallback
  if (!origin) return true; // non-browser requests (server-to-server, curl) send no Origin header
  const o = normalizeOrigin(origin);
  const withWww = configuredOrigin.replace(/^https?:\/\//, m => m).replace(/^(https?:\/\/)(?!www\.)/, '$1www.');
  const withoutWww = configuredOrigin.replace(/^(https?:\/\/)www\./, '$1');
  return o === configuredOrigin || o === withWww || o === withoutWww;
}

app.use(cors({
  origin: (origin, callback) => callback(null, isAllowedOrigin(origin)),
  credentials: true,
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { message: 'Too many login attempts. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  message: { message: 'Too many requests. Slow down.' },
});

// ── Body parsing ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(mongoSanitize());

if (process.env.NODE_ENV === 'development') app.use(morgan('dev'));

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);
app.use('/api/auth', require('./routes/auth'));
app.use('/api/leads', apiLimiter, require('./routes/leads'));
app.use('/api/followups', apiLimiter, require('./routes/followups'));
app.use('/api/campaigns', apiLimiter, require('./routes/campaigns'));
app.use('/api/reports', apiLimiter, require('./routes/reports'));
app.use('/api/users', apiLimiter, require('./routes/users'));
app.use('/api/courses', apiLimiter, require('./routes/courses'));
app.use('/api/blocklist', apiLimiter, require('./routes/blocklist'));
app.use('/api/message-templates', apiLimiter, require('./routes/messageTemplates'));
app.use('/api/broadcasts', apiLimiter, require('./routes/broadcasts'));
app.use('/api/whatsapp-inbox', apiLimiter, require('./routes/whatsappInbox'));
app.use('/api/whatsapp-lists', apiLimiter, require('./routes/whatsappLists'));
app.use('/api/bulk-import', apiLimiter, require('./routes/bulkImport'));
app.use('/api/ai-caller', require('./routes/aiCaller'));
app.use('/api/ai-call-reports', apiLimiter, require('./routes/aiCallReports')); // NEW: AI Call Reports extension
app.use('/api/integrations', require('./routes/integrations'));
app.use('/api/notifications', apiLimiter, require('./routes/notifications'));
app.use('/api/recordings', apiLimiter, require('./routes/recordings'));

// ── Audio streaming with proper Range support and CORS headers ────────────────
const RECORDINGS_DIR = process.env.RECORDINGS_DIR
  || (process.env.NODE_ENV === 'production'
    ? path.join('/var/data', 'recordings')
    : path.join(__dirname, 'uploads', 'recordings'));

app.use('/uploads/recordings', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', isAllowedOrigin(req.headers.origin) ? (req.headers.origin || '*') : 'null');
  res.setHeader('Access-Control-Allow-Headers', 'Range');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Accept-Ranges, Content-Length');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
}, express.static(RECORDINGS_DIR, {
  setHeaders: (res, filePath) => {
    if (/\.(m4a|mp3|wav|amr|3gp|3gpp|aac|ogg)$/i.test(filePath)) {
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));

// Any other (non-recording) uploads still served from the local repo path
app.use('/uploads', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', isAllowedOrigin(req.headers.origin) ? (req.headers.origin || '*') : 'null');
  res.setHeader('Access-Control-Allow-Headers', 'Range');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Accept-Ranges, Content-Length');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
}, express.static(path.join(__dirname, 'uploads'), {
  setHeaders: (res, filePath) => {
    if (/\.(m4a|mp3|wav|amr|3gp|3gpp|aac|ogg)$/i.test(filePath)) {
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));

app.use('/api/workflows', apiLimiter, require('./routes/workflows'));
app.use('/api/salesforms', apiLimiter, require('./routes/salesforms'));
app.use('/api/api-templates', apiLimiter, require('./routes/apiTemplates'));
app.use('/api/webhooks', apiLimiter, require('./routes/webhooks'));
app.use('/api/access-tokens', apiLimiter, require('./routes/accessTokens'));
app.use('/api/call-iq-agents', apiLimiter, require('./routes/callIqAgents'));
app.use('/api/mcp', apiLimiter, require('./routes/mcp'));
app.use('/mcp', apiLimiter, require('./routes/mcpServer'));
app.use('/api/n8n', apiLimiter, require('./routes/n8n'));
app.use('/api/email-campaigns', apiLimiter, require('./routes/emailCampaigns'));
app.use('/api/lead-stages', apiLimiter, require('./routes/leadStages'));
app.use('/api/lead-fields', apiLimiter, require('./routes/leadFields'));
app.use('/api/call-feedback', apiLimiter, require('./routes/callFeedback'));
app.use('/api/custom-actions', apiLimiter, require('./routes/customActions'));
app.use('/api/workspace-preferences', apiLimiter, require('./routes/workspacePreferences'));
app.use('/api/permission-templates', apiLimiter, require('./routes/permissionTemplates'));
app.use('/api/billing', apiLimiter, require('./routes/billing'));
app.use('/api/public', apiLimiter, require('./routes/publicApi'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', app: 'AOTMS Backend' }));

app.set('trust proxy', 1);

// ── Error handler ─────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: err.message || 'Server error' });
});

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

// ── AI Call Orchestrator WebSocket ────────────────────────────────────────────
// Replaces the external RunPod/Python orchestrator entirely.
// Exotel's AgentStream connects here (wss://your-render-url/ai-caller/stream)
// for each outbound call. Each connection gets its own handleCall() instance
// running Sarvam STT → GPT-4.1-mini → Sarvam TTS in-process.
// No GPU, no Docker, no RunPod — just this Node.js process on Render.
const wss = new WebSocketServer({ server, path: '/ai-caller/stream' });
wss.on('connection', (ws, req) => {
  handleCall(ws, req).catch((err) =>
    console.error('[orchestrator] unhandled error in handleCall:', err.message)
  );
});
console.log('[server] AI orchestrator WS mounted at /ai-caller/stream');

server.listen(PORT, () => {
  console.log(`🚀 AOTMS Server running on port ${PORT}`);
  startSchedulePoller(60 * 1000);
  startOverdueTaskChecker(5 * 60 * 1000);
  campaignEngine.startPoller();
  callbackEngine.startPoller();
  startSheetsAutoSyncPoller(2 * 60 * 1000); // auto-import new Google Sheet rows every 2 minutes
  console.log('[server] AI campaign engine and callback engine started');
});

// Keep-alive self-ping every 10 minutes (Render free tier spin-down prevention)
const SELF_URL = process.env.PUBLIC_BASE_URL;
if (SELF_URL) {
  setInterval(() => {
    http.get(`${SELF_URL.replace('https', 'http')}/api/health`, (res) => {
      console.log('[keep-alive] ping:', res.statusCode);
    }).on('error', () => {
      const https = require('https');
      https.get(`${SELF_URL}/api/health`, () => {}).on('error', () => {});
    });
  }, 10 * 60 * 1000);
}

module.exports = app;